To utilize the makefile type: make sudoku_solver

Input is taken as a parameter (filepath to the location of the solution file) or is defaulted to "solution.txt"

All the rest of the information pertaining to this lab is in the lab .pdf file
